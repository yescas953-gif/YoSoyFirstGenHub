# 🌟 LA Youth Opportunities Hub

A free bilingual (English/Spanish) website for LA high school students to find paid internships, volunteer programs, free fellowships, and college application guidance.

---

## 🚀 HOW TO PUBLISH THIS WEBSITE (Step-by-Step)

### Step 1 — Create a GitHub Account
1. Go to **github.com** and click **Sign Up**
2. Use any email — it's free
3. Choose a username (e.g., `layouthhub` or your name)

---

### Step 2 — Create a New Repository
1. After signing in, click the **+** icon (top right) → **New repository**
2. Name it exactly: `la-youth-hub`
3. Set it to **Public**
4. ✅ Check "Add a README file"
5. Click **Create repository**

---

### Step 3 — Upload the Website Files
1. In your new repository, click **Add file** → **Upload files**
2. Upload these two items:
   - `index.html` (the main website file)
   - The `.github` folder (contains the auto-update workflow)
   
   > **Note:** To upload the `.github` folder, you may need to drag the entire `la-youth-hub` folder contents into the upload area.

3. Click **Commit changes**

---

### Step 4 — Enable GitHub Pages
1. In your repository, click **Settings** (top menu)
2. Scroll down to **Pages** in the left sidebar
3. Under **Source**, select **GitHub Actions**
4. Click **Save**

---

### Step 5 — Trigger the First Deploy
1. Click the **Actions** tab in your repository
2. Click on **Deploy LA Youth Hub (Bi-Weekly Auto-Update)**
3. Click **Run workflow** → **Run workflow** (green button)
4. Wait about 2 minutes

---

### Step 6 — View Your Live Website! 🎉
Your site will be live at:
```
https://YOUR-GITHUB-USERNAME.github.io/la-youth-hub/
```

Example: if your username is `maria_lopez`, your URL is:
`https://maria_lopez.github.io/la-youth-hub/`

---

## 🔄 AUTOMATIC UPDATES

The site **auto-updates every 2 weeks** (on the 1st and 15th of each month) via GitHub Actions. This means:

- Deadline urgency levels update automatically based on today's date
- Programs with passed deadlines are automatically marked as expired
- The "last updated" timestamp refreshes automatically

No manual work needed after the initial setup!

---

## ✏️ HOW TO UPDATE PROGRAMS OR DEADLINES

To add/edit programs or deadlines:
1. Open `index.html` in your repository on GitHub
2. Click the ✏️ **Edit** (pencil) icon
3. Find the `PROGRAMS` or `DEADLINES` array in the JavaScript
4. Make your changes
5. Click **Commit changes**

The site will automatically redeploy within 2 minutes.

---

## 📋 WHAT'S INCLUDED

- 💼 **Paid Internships** — USC YRP, Bresee YLP, GFL, LACDPH
- 🎓 **Free Programs** — UCLA Riordan, USC Bovard, Harbor-UCLA Research
- ❤️ **Volunteer** — UCLA Health, Cedars-Sinai, LAPL, CHLA, 826LA
- 📄 **Resume Help** — 4 templates with full guides
- 📅 **Deadlines** — Auto-updated urgency calendar
- 🏛️ **College Apps** — Grade-by-grade timeline, all 2026 UC PIQs, Common App prompts
- 🔗 **Resources** — Counseling, interview prep, scholarships
- 🌐 **Bilingual** — Full English/Spanish toggle

---

## 📞 Questions?
Contact your school counselor or LAUSD College & Career center for additional support.
